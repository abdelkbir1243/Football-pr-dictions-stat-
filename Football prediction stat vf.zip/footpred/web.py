"""Pipeline de publication pour la plateforme web : produit les fichiers JSON lus par le frontend Next.js (web/data/).

    python -m footpred.web --sortie web/data              # données du jour (sources réelles, voir footpred/sources.py)
    python -m footpred.web --rejeu 2026-08-29             # rejoue une date passée (tests, démonstration hors ligne)

Aucune donnée n'est simulée. Modes :
- « live »     : calendrier, statuts et scores de football-data.org (clé FOOTBALL_DATA_API_KEY) ;
- « fixtures » : calendrier et cotes de football-data.co.uk (sans clé), résultats réels des derniers jours ;
- « offline »  : aucune source joignable, seuls les derniers résultats connus sont affichés ;
- « replay »   : une date passée est rejouée ; le modèle ne voit que les données antérieures à cette date.
Chaque prédiction d'un match à venir est figée avant le coup d'envoi dans journal.json.
"""
import argparse
import json
import os
from datetime import date, datetime, timedelta, timezone

import numpy as np
import pandas as pd

from . import config as C
from . import evaluation as E
from . import live
from . import statistiques as ST
from . import analyse as AN
from . import confiance as CF
from . import sources as SRC
from .data import charger_matchs
from .decision import classement, definitions, trois_decisions
from .equipes import COMPETITIONS, PAR_CODE, code, couleur, nom, slug
from .features import construire
from .models import ModeleComplet
from .predict import Predicteur


def ts(equipe: str) -> str:
    """Slug d'URL d'une équipe, à partir de son nom complet : « Man City » → manchester-city."""
    return slug(nom(equipe))


VERSION = "v5.0"
RES = {"V": "W", "N": "D", "D": "L"}


def _r(x, n=4):
    return None if x is None or (isinstance(x, float) and np.isnan(x)) else round(float(x), n)


# ================================================================ données de base
def equipes_saison(D: pd.DataFrame) -> dict[str, list[str]]:
    out = {}
    for lg in C.LIGUES:
        d = D[D.Division == lg]
        s = int(d.Season.max())
        eq = set(d[d.Season == s].HomeTeam) | set(d[d.Season == s].AwayTeam)
        if len(eq) < 16:                                     # tout début de saison : compléter avec la saison précédente
            prev = d[d.Season == s - 1]
            eq |= set(prev.HomeTeam)
        out[lg] = sorted(eq)
    return out


def classement_ligue(D: pd.DataFrame, lg: str, equipes: list[str]) -> list[dict]:
    s = int(D[D.Division == lg].Season.max())
    d = D[(D.Division == lg) & (D.Season == s)].sort_values("MatchDate")
    rows = []
    for e in equipes:
        h, a = d[d.HomeTeam == e], d[d.AwayTeam == e]
        gf, ga = int(h.FTHome.sum() + a.FTAway.sum()), int(h.FTAway.sum() + a.FTHome.sum())
        w = int((h.FTHome > h.FTAway).sum() + (a.FTAway > a.FTHome).sum()); dr = int((h.FTHome == h.FTAway).sum() + (a.FTHome == a.FTAway).sum())
        n = len(h) + len(a)
        m = ST.matchs_equipe(d, e, 5) if n else None
        rows.append({"team": ts(e), "played": n, "won": w, "drawn": dr, "lost": n - w - dr, "gf": gf, "ga": ga, "gd": gf - ga,
                     "points": 3 * w + dr, "form": [RES[x] for x in m["résultat"]] if m is not None and len(m) else []})
    rows.sort(key=lambda r: (-r["points"], -r["gd"], -r["gf"], r["team"]))
    for i, r in enumerate(rows, 1):
        r["rank"] = i
    return rows


def profil_equipe(pred: Predicteur, e: str, lg: str) -> dict:
    d = pred.d
    M = ST.matchs_equipe(d.D_all, e, None)
    last = M.tail(10)
    L = d.L[d.L.team == e].sort_values("date")
    xg = L.tail(10)
    pts = lambda m: float(((m["résultat"] == "V") * 3 + (m["résultat"] == "N")).mean()) if len(m) else None
    home, away = M[M.lieu == "dom"].tail(10), M[M.lieu == "ext"].tail(10)
    sf, sa = last["Tirs_pour"].mean(), last["Tirs_contre"].mean()

    def bloc(m):
        if not len(m):
            return None
        return {"played": len(m), "ppg": _r(pts(m), 2), "gf": _r(m["Buts marqués_pour"].mean(), 2), "ga": _r(m["Buts marqués_contre"].mean(), 2),
                "winPct": _r((m["résultat"] == "V").mean(), 3)}
    s = int(d.D[d.D.Division == lg].Season.max())
    saison = M[M.date.dt.year.isin([s, s + 1]) & (M.date >= f"{s}-07-01")]
    return {
        "slug": ts(e), "name": nom(e), "short": e, "code": code(e), "color": couleur(e), "competition": PAR_CODE[lg]["slug"],
        "country": PAR_CODE[lg]["country"], "stadium": None, "coach": None, "elo": _r(L.elo.dropna().iloc[-1], 0) if L.elo.notna().any() else None,
        "form": [RES[x] for x in last["résultat"].tail(5)],
        "lastMatches": [{"date": r.date.date().isoformat(), "opponent": ts(r.adversaire), "opponentName": nom(r.adversaire),
                         "venue": "home" if r.lieu == "dom" else "away", "gf": int(r["Buts marqués_pour"]), "ga": int(r["Buts marqués_contre"]),
                         "result": RES[r["résultat"]], "competition": PAR_CODE.get(r.Division, {}).get("slug")} for _, r in last.iloc[::-1].iterrows()],
        "stats": {
            "window": len(last), "ppg": _r(pts(last), 2), "goalsFor": _r(last["Buts marqués_pour"].mean(), 2), "goalsAgainst": _r(last["Buts marqués_contre"].mean(), 2),
            "xgFor": _r(xg.xg_f.mean(), 2), "xgAgainst": _r(xg.xg_a.mean(), 2), "shots": _r(sf, 1), "shotsAgainst": _r(sa, 1),
            "shotsOnTarget": _r(last["Tirs cadrés_pour"].mean(), 1), "corners": _r(last["Corners obtenus_pour"].mean(), 1),
            "cornersAgainst": _r(last["Corners obtenus_contre"].mean(), 1), "yellow": _r(last["Cartons jaunes_pour"].mean(), 2),
            "red": _r(last["Cartons rouges_pour"].mean(), 2), "fouls": _r(last["Fautes commises_pour"].mean(), 1),
            "shotShare": _r(sf / (sf + sa), 3) if sf + sa > 0 else None,
            "cleanSheetPct": _r((last["Buts marqués_contre"] == 0).mean(), 3),
            "over25Pct": _r((last["Buts marqués_pour"] + last["Buts marqués_contre"] > 2.5).mean(), 3),
            "bttsPct": _r(((last["Buts marqués_pour"] > 0) & (last["Buts marqués_contre"] > 0)).mean(), 3),
            "home": bloc(home), "away": bloc(away),
            "season": {"label": f"{s}/{(s + 1) % 100:02d}", **(bloc(saison) or {"played": 0})},
        },
        "eloHistory": [{"date": r.date.date().isoformat(), "elo": _r(r.elo, 0)} for _, r in L.dropna(subset=["elo"]).tail(40).iterrows()],
        "_radar_raw": {"attack": xg.xg_f.mean(), "defense": -xg.xg_a.mean(), "form": pts(last.tail(5)),
                       "control": sf / (sf + sa) if sf + sa > 0 else np.nan,
                       "finishing": last["Buts marqués_pour"].sum() / max(xg.xg_f.sum(), 1e-6),
                       "venueHome": pts(home), "venueAway": pts(away)},
    }


def radars(profils: list[dict]):
    """Percentiles (0-100) de chaque dimension au sein de la ligue."""
    df = pd.DataFrame({p["slug"]: p["_radar_raw"] for p in profils}).T.astype(float)
    pct = (df.rank(pct=True) * 100).round(0)
    for p in profils:
        p["radar"] = {k: _r(v, 0) for k, v in pct.loc[p["slug"]].items()}
        del p["_radar_raw"]


def h2h(D: pd.DataFrame, a: str, b: str, n: int = 10) -> dict:
    H = D[((D.HomeTeam == a) & (D.AwayTeam == b)) | ((D.HomeTeam == b) & (D.AwayTeam == a))].sort_values("MatchDate").tail(n)
    if H.empty:
        return {"matches": [], "summary": None}
    ga = np.where(H.HomeTeam == a, H.FTHome, H.FTAway); gb = np.where(H.HomeTeam == a, H.FTAway, H.FTHome)
    tot = H.FTHome + H.FTAway
    return {"matches": [{"date": r.MatchDate.date().isoformat(), "home": ts(r.HomeTeam), "away": ts(r.AwayTeam),
                         "homeGoals": int(r.FTHome), "awayGoals": int(r.FTAway), "competition": PAR_CODE.get(r.Division, {}).get("slug")}
                        for _, r in H.iloc[::-1].iterrows()],
            "summary": {"n": len(H), "homeWins": int((ga > gb).sum()), "draws": int((ga == gb).sum()), "awayWins": int((ga < gb).sum()),
                        "avgGoals": _r(tot.mean(), 2), "bttsPct": _r(((H.FTHome > 0) & (H.FTAway > 0)).mean(), 3),
                        "over25Pct": _r((tot > 2.5).mean(), 3), "cleanSheetsHome": int((gb == 0).sum()), "cleanSheetsAway": int((ga == 0).sum())}}


# ================================================================ prédiction d'un match
def synthese(r, pa, pb, dom, ext) -> str:
    p1, px, p2 = r["1"], r["X"], r["2"]
    fav, autre, pf, po = (dom, ext, p1, p2) if p1 >= p2 else (ext, dom, p2, p1)
    ecart = pf - po
    if ecart < 0.08:
        tete = f"L'analyse statistique ne dégage pas de favori clair entre {dom} et {ext}"
    else:
        force = "un net avantage" if ecart > 0.30 else ("un avantage" if ecart > 0.15 else "un léger avantage")
        sa, sb = (pa, pb) if fav == dom else (pb, pa)
        moteurs = []
        if (sa["stats"]["ppg"] or 0) - (sb["stats"]["ppg"] or 0) > 0.4:
            moteurs.append("sa forme récente")
        if (sa["elo"] or 0) - (sb["elo"] or 0) > 60:
            moteurs.append("un niveau global (Elo) supérieur")
        if (sa["stats"]["xgFor"] or 0) - (sb["stats"]["xgFor"] or 0) > 0.25:
            moteurs.append("une production offensive plus élevée")
        if (sb["stats"]["xgAgainst"] or 0) - (sa["stats"]["xgAgainst"] or 0) > 0.25:
            moteurs.append("une défense plus solide")
        lieu = pa["stats"]["home"] if fav == dom else pb["stats"]["away"]
        if lieu and (lieu["ppg"] or 0) >= 2.0:
            moteurs.append("ses performances à domicile" if fav == dom else "ses performances à l'extérieur")
        if fav == dom and not moteurs:
            moteurs.append("l'avantage du terrain")
        raison = (", principalement lié à " + " et ".join(moteurs[:2])) if moteurs else ""
        tete = f"L'analyse statistique indique {force} pour {fav}{raison}"
    inc = "reste élevé" if max(p1, px, p2) < 0.45 else ("reste toutefois significatif" if max(p1, px, p2) < 0.62 else "est plus modéré qu'à l'accoutumée")
    nul = f" Le match nul demeure une issue crédible ({px:.0%})." if px >= 0.28 else ""
    return f"{tete}. Le niveau d'incertitude {inc}.{nul}".replace(".0%", "%")


def prediction(pred: Predicteur, dom: str, ext: str, profils: dict, jour=None, cotes=None, ligne=None, comp: AN.Comparables | None = None, lg=None,
               conf: dict | None = None, brut: dict | None = None) -> dict:
    """Prédiction et analyse statistique complète d'un match.
    `ligne` (variables d'avant-match d'un match déjà joué) : prédiction hors échantillon avec un modèle des saisons précédentes."""
    r = pred.predire_ligne(ligne) if ligne is not None else pred.predire(dom, ext, jour=jour, lg=lg)
    r["dom"], r["ext"] = nom(dom), nom(ext)
    T = classement(r)
    D3 = trois_decisions(T, ["Résultat", "Double chance", "Buts", "Corners"])
    v = r["variables"]
    h, a = pred.d.L[pred.d.L.team == dom].tail(10), pred.d.L[pred.d.L.team == ext].tail(10)
    sf = lambda t, c: t[c].mean() if len(t) else np.nan
    ctrl_n, ctrl_d = sf(h, "sf") + sf(a, "sa"), sf(h, "sf") + sf(a, "sa") + sf(a, "sf") + sf(h, "sa")
    (ps, sc) = r["scores"][0]
    pa, pb = profils.get(ts(dom)), profils.get(ts(ext))
    c, j = r["corners"], r["jaunes"]
    # degré de confiance : calibration de chaque statistique + niveau du match (mesurés hors échantillon, données du jour)
    generique = {n: g for (_, n, _, _), (_, g, _, _) in zip(definitions(r["dom"], r["ext"]), definitions("Domicile", "Extérieur"))}
    P3 = np.array([r["1"], r["X"], r["2"]])
    ecart = None
    if cotes and all(cotes.get(k) for k in ("home", "draw", "away")):
        ecart = float(CF.ecart_marche(P3[None, :], np.array([[cotes["home"], cotes["draw"], cotes["away"]]], float))[0])
    k_ = r.get("contexte") or {}
    jm = min(k_.get("joues_h") if k_.get("joues_h") is not None else np.nan, k_.get("joues_a") if k_.get("joues_a") is not None else np.nan)
    fav = [r["dom"], "Match nul", r["ext"]][int(P3.argmax())]
    trust = CF.confiance_match(conf["levels"], float(P3.max()), ecart, jm, fav) if conf else None
    cal_of = lambda nm, p: CF.chercher(conf["calibration"], generique.get(nm, nm), p) if conf else None
    if brut is not None:
        M_ = r["_M"]; G = np.arange(M_.shape[0])
        brut.update({"goals": np.bincount((G[:, None] + G[None, :]).ravel(), weights=M_.ravel()), "corners": c.get("loi"), "p": P3,
                     "o25": r["over25"], "level": trust["level"] if trust else None})
    return {
        "model": VERSION, "home": _r(r["1"]), "draw": _r(r["X"]), "away": _r(r["2"]),
        "confidence": _r(r["precision_historique"], 2), "reliability": r["fiabilite"], "endOfSeason": bool(r["fin_de_saison"]),
        "xg": {"home": _r(r["buts_dom"], 2), "away": _r(r["buts_ext"], 2), "total": _r(r["buts_dom"] + r["buts_ext"], 2)},
        "likelyScore": {"home": int(sc.split("-")[0]), "away": int(sc.split("-")[1]), "p": _r(ps, 3)},
        "topScores": [{"score": s, "p": _r(q, 3)} for q, s in r["scores"]],
        "over15": _r(r["over15"]), "over25": _r(r["over25"]), "over35": _r(r["over35"]), "btts": _r(r["btts"]),
        "cleanSheetHome": _r(r["cs_dom"]), "cleanSheetAway": _r(r["cs_ext"]), "firstHalfGoal": _r(r["but_1re_MT"]),
        "control": _r(ctrl_n / ctrl_d, 3) if np.isfinite(ctrl_n / ctrl_d) else None,
        "corners": {"total": _r(c["total"], 2), "home": _r(c["dom"], 2), "away": _r(c["ext"], 2), "over": {str(k): _r(x) for k, x in c["plus_de"].items()}},
        "cards": {"total": _r(j["total"], 2), "home": _r(j["dom"], 2), "away": _r(j["ext"], 2), "over": {str(k): _r(x) for k, x in j["plus_de"].items()},
                  "red": _r(r["rouges"]["au_moins_un"])},
        "markets": [{"family": t.famille, "market": t["marché"], "p": _r(t["probabilité"]), "tier": t.risque, "cal": cal_of(t["marché"], t["probabilité"]),
                     "key": generique.get(t["marché"], t["marché"])}
                    for _, t in T.iterrows()],
        "trust": trust,
        "decisions": [{"profile": d.profil, "market": d["marché"], "p": _r(d["probabilité"]), "tier": d.risque} for _, d in D3.iterrows()],
        "synthesis": synthese(r, pa, pb, nom(dom), nom(ext)) if pa and pb else "",
        "expected": AN.attendus(r),
        "similar": comp.chercher(v, lg or pred.d.ligue_match(dom, ext)) if comp else None,
        "context": AN.contexte(r.get("contexte"), nom(dom), nom(ext)),
        "market": AN.marche(r, cotes),
        "source": "out-of-sample" if ligne is not None else "pre-match",
    }


# ================================================================ calendrier (sources réelles uniquement)
def _iso(ts_: pd.Timestamp, heure="15:00") -> str:
    """Date sans heure (historique) → coup d'envoi indicatif 15:00 UTC."""
    return f"{ts_.date().isoformat()}T{heure}:00Z"


def matchs_historiques(raw: pd.DataFrame, debut: date, fin: date, statut_avant: date | None = None) -> list[dict]:
    """Matchs réels du dataset entre deux dates (incluses). Avec `statut_avant` (rejeu), les matchs à partir de cette date
    sont présentés « à venir » : score et statistiques masqués, cotes d'avant-match conservées."""
    d = raw[raw.Division.isin(C.LIGUES) & (raw.MatchDate.dt.date >= debut) & (raw.MatchDate.dt.date <= fin)].dropna(subset=["FTHome"])
    out = []
    for r in d.itertuples():
        futur = statut_avant is not None and r.MatchDate.date() >= statut_avant
        num = lambda x: None if pd.isna(x) else int(x)
        odds = {k: float(v) for k, v in (("home", r.OddHome), ("draw", r.OddDraw), ("away", r.OddAway), ("over25", getattr(r, "Over25", np.nan)),
                                           ("under25", getattr(r, "Under25", np.nan))) if pd.notna(v) and v > 1}
        stats = None if futur else {k: {"home": num(getattr(r, f"Home{c}", np.nan)), "away": num(getattr(r, f"Away{c}", np.nan))}
                                    for k, c in (("shots", "Shots"), ("shotsOnTarget", "Target"), ("corners", "Corners"), ("yellow", "Yellow"),
                                                 ("red", "Red"), ("fouls", "Fouls"))}
        out.append({"id": f"h-{r.MatchDate.date().isoformat()}-{ts(r.HomeTeam)}-{ts(r.AwayTeam)}", "competition": r.Division,
                    "kickoff": _iso(r.MatchDate), "status": "scheduled" if futur else "finished", "home": r.HomeTeam, "away": r.AwayTeam,
                    "venue": None, "score": None if futur else {"home": int(r.FTHome), "away": int(r.FTAway)},
                    "halftime": None if futur or pd.isna(r.HTHome) else {"home": int(r.HTHome), "away": int(r.HTAway)},
                    "stats": stats, "odds": odds or None, "timeKnown": False})
    return out


def calendrier_fdorg(pred, eq_ligue, jour0, key) -> list[dict]:
    toutes = sorted({e for v in eq_ligue.values() for e in v} | set(pred.d.L.team.unique()))
    out = []
    for m in live.matchs_api(jour0 - timedelta(days=3), jour0 + timedelta(days=7), key):
        c = live.convertir(m, eq_ligue, toutes)
        if c and c["home"] and c["away"]:
            out.append(c | {"timeKnown": True})
    return out


def rattacher_cotes(cal: list[dict], fixtures: list[dict]):
    """Ajoute aux matchs du calendrier les cotes d'avant-match de football-data.co.uk (même jour, mêmes équipes)."""
    idx = {(f["kickoff"][:10], f["home"], f["away"]): f.get("odds") for f in fixtures}
    for m in cal:
        if not m.get("odds"):
            m["odds"] = idx.get((m["kickoff"][:10], m["home"], m["away"]))


def collecter(raw: pd.DataFrame, jour0: date, key: str | None) -> tuple[pd.DataFrame, str, callable, dict]:
    """Complète l'historique avec les résultats récents puis renvoie une fonction de calendrier selon les sources joignables."""
    info = {"sources": [], "resultsAdded": 0}
    try:
        raw, n = SRC.fusionner(raw, SRC.resultats_fduk(jour0))
        info["resultsAdded"] += n
        if n:
            info["sources"].append("football-data.co.uk (résultats)")
    except Exception as e:
        print("⚠ résultats football-data.co.uk indisponibles :", e)
    if key:
        try:
            raw2, n = completer_avec_api(raw, key, equipes_saison(raw[raw.Division.isin(C.LIGUES)]))
            raw, info["resultsAdded"] = raw2, info["resultsAdded"] + n
            if n:
                info["sources"].append("football-data.org (résultats)")
        except Exception as e:
            print("⚠ football-data.org indisponible :", e)
    return SRC.propager_elo(raw), info


def calendrier(pred, raw, eq_ligue, jour0: date, key: str | None, info: dict) -> tuple[str, list[dict]]:
    fixtures = []
    try:
        fixtures = SRC.calendrier_fduk()
    except Exception as e:
        print("⚠ calendrier football-data.co.uk indisponible :", e)
    recents = matchs_historiques(raw, jour0 - timedelta(days=3), jour0)
    for src in SRC.ordre_sources():
        if src == "footballdata_org" and key:
            try:
                cal = calendrier_fdorg(pred, eq_ligue, jour0, key)
                if cal:
                    rattacher_cotes(cal, fixtures)
                    info["sources"].append("football-data.org (calendrier, direct)")
                    return "live", cal
            except Exception as e:
                print("⚠ calendrier football-data.org indisponible :", e)
        if src == "football_data_co_uk" and fixtures:
            info["sources"].append("football-data.co.uk (calendrier, cotes)")
            vus = {(m["kickoff"][:10], m["home"], m["away"]) for m in recents}
            futurs = [f | {"timeKnown": True} for f in fixtures if (f["kickoff"][:10], f["home"], f["away"]) not in vus]
            return "fixtures", recents + futurs
    # aucune source de calendrier : derniers résultats réels connus
    der = raw[raw.Division.isin(C.LIGUES)].MatchDate.max().date()
    return "offline", matchs_historiques(raw, der - timedelta(days=6), der)


# ================================================================ performances
def performances(pred: Predicteur, journal: dict) -> dict:
    X = pred.d.X
    saisons = sorted(s for s in X.Season.unique() if s >= 2025)
    te, r = E.walk_forward(X, saisons)
    y = te.y.values; P = r["P"]; n = len(y)
    Pm = E.proba_cotes(te); ok = ~np.isnan(Pm).any(1)
    base = np.bincount(y, minlength=3) / n
    pv = P.ravel(); ov = np.eye(3)[y].ravel()
    q = pd.qcut(pv, 10, labels=False, duplicates="drop")
    cal = pd.DataFrame({"p": pv, "o": ov, "b": q}).groupby("b").agg(predicted=("p", "mean"), observed=("o", "mean"), n=("p", "size"))
    df = te.assign(ll=E.log_loss(P, y), ok=P.argmax(1) == y, llm=np.where(ok, E.log_loss(np.nan_to_num(Pm, nan=1 / 3), y), np.nan),
                   brier=E.brier(P, y), mois=te.MatchDate.dt.strftime("%Y-%m"))
    mois = df.groupby("mois").agg(logLoss=("ll", "mean"), marketLogLoss=("llm", "mean"), accuracy=("ok", "mean"), brier=("brier", "mean"), n=("ll", "size"))
    hist = df.assign(pH=P[:, 0], pD=P[:, 1], pA=P[:, 2]).sort_values("MatchDate", ascending=False).head(400)
    lab = ["H", "D", "A"]
    paliers = None
    f = os.path.join(os.path.dirname(__file__), "..", "results", "tables", "decisions_2021_2026_paliers.csv")
    if os.path.exists(f):
        t = pd.read_csv(f)
        paliers = [{"tier": row.palier, "decisions": int(row["décisions"]), "predicted": _r(row["probabilité_annoncée"]), "observed": _r(row["taux_réalisé"]),
                    "returnAtOdds": _r(row["rendement_aux_cotes"])} for _, row in t.iterrows()]
    # journal en direct (mode réel) : prédictions figées avant le match
    J = [v for v in journal.values() if v.get("result")]
    live_stats = None
    if J:
        jy = np.array([lab.index(v["result"]) for v in J]); jp = np.array([[v["pH"], v["pD"], v["pA"]] for v in J])
        live_stats = {"n": len(J), "accuracy": _r(np.mean(jp.argmax(1) == jy)), "logLoss": _r(E.log_loss(jp, jy).mean()), "brier": _r(E.brier(jp, jy).mean())}
    return {
        "scope": f"Test hors échantillon {saisons[0]}/{(saisons[0] + 1) % 100:02d} → aujourd'hui (walk-forward : chaque saison prédite par un modèle entraîné sur les saisons antérieures)",
        "matches": n, "accuracy": _r(np.mean(P.argmax(1) == y)), "logLoss": _r(E.log_loss(P, y).mean()), "brier": _r(E.brier(P, y).mean()),
        "rps": _r(E.rps(P, y).mean()), "ece": _r(E.ece(P, y)),
        "baseline": {"logLoss": _r(E.log_loss(np.tile(base, (n, 1)), y).mean()), "accuracy": _r(base.max())},
        "market": {"logLoss": _r(E.log_loss(Pm[ok], y[ok]).mean()), "accuracy": _r(np.mean(Pm[ok].argmax(1) == y[ok])), "brier": _r(E.brier(Pm[ok], y[ok]).mean())},
        "calibration": [{"predicted": _r(row.predicted), "observed": _r(row.observed), "n": int(row.n)} for _, row in cal.iterrows()],
        "byMonth": [{"month": m, **{k: _r(v) for k, v in row.items() if k != "n"}, "n": int(row.n)} for m, row in mois.iterrows()],
        "tiers": paliers, "live": live_stats,
        "history": [{"date": row.MatchDate.date().isoformat(), "competition": PAR_CODE[row.Division]["slug"], "home": ts(row.HomeTeam), "away": ts(row.AwayTeam),
                     "homeName": nom(row.HomeTeam), "awayName": nom(row.AwayTeam), "pH": _r(row.pH, 3), "pD": _r(row.pD, 3), "pA": _r(row.pA, 3),
                     "predicted": lab[int(np.argmax([row.pH, row.pD, row.pA]))], "actual": lab[int(row.y)], "score": f"{int(row.FTHome)}-{int(row.FTAway)}",
                     "correct": bool(row.ok)} for _, row in hist.iterrows()],
    }


# ================================================================ export principal
def completer_avec_api(raw, key, eq_ligue):
    """Ajoute au dataset les résultats récents de football-data.org (sans statistiques détaillées) pour mettre à jour les ratings."""
    depuis = raw[raw.Division.isin(C.LIGUES)].MatchDate.max().date() + timedelta(days=1)
    if depuis > date.today():
        return raw, 0
    toutes = sorted({e for v in eq_ligue.values() for e in v})
    nouv = live.resultats_recents(depuis, key, eq_ligue, toutes)
    if not nouv:
        return raw, 0
    add = pd.DataFrame([{"Division": m["competition"], "MatchDate": pd.Timestamp(m["kickoff"][:10]), "HomeTeam": m["home"], "AwayTeam": m["away"],
                         "FTHome": m["score"]["home"], "FTAway": m["score"]["away"],
                         "FTResult": "H" if m["score"]["home"] > m["score"]["away"] else ("D" if m["score"]["home"] == m["score"]["away"] else "A"),
                         "HTHome": (m["halftime"] or {}).get("home"), "HTAway": (m["halftime"] or {}).get("away")} for m in nouv])
    return SRC.fusionner(raw, add)


def journees(matchs: list[dict], bruts: dict, conf: dict) -> dict:
    """Analyse de chaque journée (date de Paris) : attendus de la journée avec intervalles à 80 %, niveaux de confiance,
    statistiques les mieux étayées et, pour les matchs joués, bilan attendu contre observé."""
    from zoneinfo import ZoneInfo
    paris = ZoneInfo("Europe/Paris")
    par_jour = {}
    for m in matchs:
        if not m.get("prediction") or m["id"] not in bruts or "p" not in bruts[m["id"]]:
            continue
        j = datetime.fromisoformat(m["kickoff"].replace("Z", "+00:00")).astimezone(paris).date().isoformat()
        par_jour.setdefault(j, []).append(m)
    out = {}
    for j, ms in sorted(par_jour.items()):
        b = [bruts[m["id"]] for m in ms]
        P = np.array([x["p"] for x in b])
        buts = CF.convoluer([x["goals"] for x in b])
        cor = [x["corners"] for x in b if x.get("corners") is not None]
        cor_loi = CF.convoluer(cor) if cor else None
        def bloc(probas):
            loi = CF.poisson_binomiale(list(probas))
            return {"expected": _r(float(np.sum(probas)), 2), "range": CF.intervalle(loi)}
        niveaux = {k: sum(1 for x in b if x["level"] == k) for k in ("A", "B", "C")}
        # statistiques les mieux étayées : issue probable (60-92 %) dont la calibration historique a la borne basse la plus haute
        cand = []
        for m in ms:
            for k in m["prediction"].get("markets", []):
                c = k.get("cal")
                if c and 0.6 <= (k["p"] or 0) <= 0.92 and c["n"] >= 200:
                    cand.append({"match": m["slug"], "key": k.get("key"), "homeName": m["homeName"], "awayName": m["awayName"], "market": k["market"], "family": k["family"],
                                 "p": k["p"], "observed": c["observed"], "lo": c["lo"], "hi": c["hi"], "n": c["n"]})
        # classement : borne basse de l'IC (preuve la plus solide), puis probabilité ; un seul exemple par type de statistique et par match
        cand.sort(key=lambda x: (-round(x["lo"], 2), -x["p"]))
        vus, types, top = set(), set(), []
        for x in cand:
            if x["match"] not in vus and x["key"] not in types:
                top.append(x); vus.add(x["match"]); types.add(x["key"])
            if len(top) == 5:
                break
        pm = P.max(1)
        ordre = np.argsort(pm)
        resume = {"date": j, "n": len(ms), "levels": niveaux,
                  "goals": {"expected": _r(float((np.arange(len(buts)) * buts).sum()), 1), "range": CF.intervalle(buts),
                            "perMatch": _r(float((np.arange(len(buts)) * buts).sum()) / len(ms), 2)},
                  "corners": {"expected": _r(float((np.arange(len(cor_loi)) * cor_loi).sum()), 0), "range": CF.intervalle(cor_loi)} if cor_loi is not None else None,
                  "homeWins": bloc(P[:, 0]), "draws": bloc(P[:, 1]), "awayWins": bloc(P[:, 2]), "favWins": bloc(pm),
                  "over25": bloc([x["o25"] for x in b]),
                  "clearest": {"match": ms[ordre[-1]]["slug"], "label": f"{ms[ordre[-1]]['homeName']} – {ms[ordre[-1]]['awayName']}", "p": _r(float(pm[ordre[-1]]), 3)},
                  "mostOpen": {"match": ms[ordre[0]]["slug"], "label": f"{ms[ordre[0]]['homeName']} – {ms[ordre[0]]['awayName']}", "p": _r(float(pm[ordre[0]]), 3)},
                  "best": top, "result": None}
        fin = [(m, x, p) for m, x, p in zip(ms, b, P) if m["status"] == "finished" and m.get("score")]
        if fin:
            sc = np.array([[m["score"]["home"], m["score"]["away"]] for m, _, _ in fin])
            Pf = np.array([p for _, _, p in fin]); y = np.where(sc[:, 0] > sc[:, 1], 0, np.where(sc[:, 0] == sc[:, 1], 1, 2))
            resume["result"] = {"n": len(fin), "goals": int(sc.sum()), "goalsExpected": _r(float(sum((np.arange(len(x["goals"])) * x["goals"]).sum() for _, x, _ in fin)), 1),
                                "homeWins": int((y == 0).sum()), "draws": int((y == 1).sum()), "awayWins": int((y == 2).sum()),
                                "favWins": int((Pf.argmax(1) == y).sum()), "favExpected": _r(float(Pf.max(1).sum()), 2),
                                "over25": int((sc.sum(1) > 2.5).sum()), "over25Expected": _r(float(sum(x["o25"] for _, x, _ in fin)), 2),
                                "logLoss": _r(float(E.log_loss(Pf, y).mean()), 4)}
        out[j] = resume
    return out


def marches_a_venir(matchs: list[dict], paliers) -> list[dict]:
    """Tous les marchés des matchs à venir, pour la page « Marchés & risque » (du moins risqué au plus risqué)."""
    out = []
    for m in matchs:
        p = m.get("prediction")
        if not p or m["status"] != "scheduled" or p.get("source") != "pre-match":
            continue
        cotes = (p.get("market") or {}).get("odds") or {}
        imp = {r["key"]: r["market"] for r in (p.get("market") or {}).get("rows", [])}
        cle = {f"Victoire {m['homeName']}": "home", "Match nul": "draw", f"Victoire {m['awayName']}": "away", "Plus de 2,5 buts": "over25"}
        for k in p["markets"]:
            if k["p"] is None or k["p"] >= 0.97:
                continue
            ck = cle.get(k["market"])
            out.append({"match": m["slug"], "kickoff": m["kickoff"], "competition": m["competition"], "home": m["home"], "away": m["away"],
                        "homeName": m["homeName"], "awayName": m["awayName"], "family": k["family"], "market": k["market"], "p": k["p"], "tier": k["tier"],
                        "fairOdds": _r(1 / k["p"], 2), "odds": cotes.get(ck) if ck else None, "marketP": imp.get(ck) if ck else None})
    out.sort(key=lambda x: -x["p"])
    return out


def exporter(sortie="web/data", source=None, jour0: date | None = None, rejeu: date | None = None):
    os.makedirs(sortie, exist_ok=True)
    key = None if rejeu else live.cle()
    raw = charger_matchs(source, cache=None)
    if rejeu:                                                   # le modèle ne voit que le passé de la date rejouée
        jour0 = rejeu
        complet, raw = raw, raw[raw.MatchDate.dt.date < rejeu].copy()
        info = {"sources": ["dataset historique (rejeu)"], "resultsAdded": 0}
    else:
        jour0 = jour0 or datetime.now(timezone.utc).date()
        raw, info = collecter(raw, jour0, key)
    date_dataset = raw[raw.Division.isin(C.LIGUES)].MatchDate.max().date()
    d = construire(raw)
    pred = Predicteur(d)
    eq_ligue = equipes_saison(d.D)
    s_cur = int(d.X.Season.max())
    pred_prec = Predicteur(d, ModeleComplet.entrainer(d.X[d.X.Season < s_cur], s_cur - 1))   # prédictions hors échantillon
    comp = AN.Comparables(d.X)
    # backtest du jour : 5 dernières saisons + saison en cours, chaque saison prédite par un modèle des saisons précédentes
    A_bt, M_bt = CF.backtest(d.X, list(range(s_cur - 5, s_cur + 1)))
    pred.calibrer_fiabilite(M_bt[["pH", "pD", "pA"]].values, M_bt.y.values)
    pred_prec.conf_acc = pred.conf_acc
    conf = {"calibration": CF.calibration_marches(A_bt), "levels": CF.table_niveaux(M_bt)}

    # calendrier (les équipes promues apparaissent dans le calendrier avant leur premier match)
    if rejeu:
        mode, cal = "replay", matchs_historiques(complet, rejeu - timedelta(days=3), rejeu + timedelta(days=7), statut_avant=rejeu)
    else:
        mode, cal = calendrier(pred, raw, eq_ligue, jour0, key, info)
    for m in cal:
        if m["competition"] in eq_ligue:
            for e in (m["home"], m["away"]):
                if e and e not in eq_ligue[m["competition"]] and (d.L.team == e).any():
                    eq_ligue[m["competition"]].append(e)

    # équipes, classements, compétitions
    profils, standings = {}, {}
    for lg, eqs in eq_ligue.items():
        ps = [profil_equipe(pred, e, lg) for e in eqs]
        radars(ps)
        profils |= {p["slug"]: p for p in ps}
        standings[PAR_CODE[lg]["slug"]] = classement_ligue(d.D, lg, eqs)
        for row in standings[PAR_CODE[lg]["slug"]]:
            profils[row["team"]]["rank"] = row["rank"]; profils[row["team"]]["points"] = row["points"]
    competitions = []
    for c in COMPETITIONS:
        n_eq = len(eq_ligue.get(c["code"], []))
        s = int(d.D[d.D.Division == c["code"]].Season.max()) if c["covered"] else None
        stats = None
        if c["covered"]:
            x = d.D[(d.D.Division == c["code"]) & (d.D.Season == s)]
            x = x if len(x) >= 30 else d.D[d.D.Division == c["code"]].tail(380)
            stats = {"matches": len(x), "goalsPerMatch": _r((x.FTHome + x.FTAway).mean(), 2), "homeWinPct": _r((x.FTHome > x.FTAway).mean(), 3),
                     "drawPct": _r((x.FTHome == x.FTAway).mean(), 3), "awayWinPct": _r((x.FTHome < x.FTAway).mean(), 3),
                     "over25Pct": _r((x.FTHome + x.FTAway > 2.5).mean(), 3), "bttsPct": _r(((x.FTHome > 0) & (x.FTAway > 0)).mean(), 3),
                     "cornersPerMatch": _r((x.HomeCorners + x.AwayCorners).mean(), 2), "yellowPerMatch": _r((x.HomeYellow + x.AwayYellow).mean(), 2)}
        competitions.append({"slug": c["slug"], "code": c["code"], "name": c["name"], "country": c["country"], "cc": c["cc"], "covered": c["covered"],
                             "zones": c["zones"], "season": f"{s}/{(s + 1) % 100:02d}" if s else None, "teams": [ts(e) for e in eq_ligue.get(c["code"], [])],
                             "nTeams": n_eq, "stats": stats})

    journal_f = os.path.join(sortie, "journal.json")
    journal = json.load(open(journal_f)) if os.path.exists(journal_f) and mode != "replay" else {}
    lignes = {(r.MatchDate.date().isoformat(), r.HomeTeam, r.AwayTeam): r for r in d.X[d.X.Season == s_cur].itertuples(index=False)} if len(d.X) else {}
    cols_X = list(d.X.columns)
    matchs, bruts = [], {}
    for m in cal:
        h, a = m["home"], m["away"]
        couvert = PAR_CODE[m["competition"]]["covered"] and ts(h) in profils and ts(a) in profils
        p = None
        try:
            if couvert and m["status"] in ("scheduled", "postponed"):
                p = prediction(pred, h, a, profils, jour=m["kickoff"][:10], cotes=m.get("odds"), comp=comp, lg=m["competition"], conf=conf, brut=bruts.setdefault(m["id"], {}))
            elif couvert and m["status"] == "finished" and (m["kickoff"][:10], h, a) in lignes:
                ligne = pd.Series(lignes[(m["kickoff"][:10], h, a)], index=cols_X)
                p = prediction(pred_prec, h, a, profils, cotes=m.get("odds"), ligne=ligne, comp=comp, conf=conf, brut=bruts.setdefault(m["id"], {}))
        except Exception as e:
            print("prédiction impossible", h, a, e)
        figer = mode in ("live", "fixtures")
        if figer and p and m["id"] not in journal and m["status"] == "scheduled":
            journal[m["id"]] = {"madeAt": datetime.now(timezone.utc).isoformat(), "kickoff": m["kickoff"], "home": ts(h), "away": ts(a),
                                "pH": p["home"], "pD": p["draw"], "pA": p["away"], "model": VERSION,
                                "prediction": {k: v for k, v in p.items() if k != "markets"}}
        if m["id"] in journal and m["status"] == "finished" and m.get("score"):
            s_ = m["score"]; journal[m["id"]]["result"] = "H" if s_["home"] > s_["away"] else ("D" if s_["home"] == s_["away"] else "A")
            journal[m["id"]]["score"] = f"{s_['home']}-{s_['away']}"
        if m["id"] in journal and m["status"] not in ("scheduled", "postponed"):       # prédiction affichée = celle figée avant le match
            fig = journal[m["id"]]
            p = {**(fig.get("prediction") or p or {}), "home": fig["pH"], "draw": fig["pD"], "away": fig["pA"], "frozenAt": fig["madeAt"],
                 "markets": [], "source": "frozen"}
        hs, as_ = ts(h), ts(a)
        matchs.append({"id": m["id"], "slug": f"{hs}-vs-{as_}", "competition": PAR_CODE[m["competition"]]["slug"], "kickoff": m["kickoff"],
                       "timeKnown": m.get("timeKnown", True), "status": m["status"], "minute": m.get("minute"), "venue": m.get("venue"),
                       "home": hs, "away": as_, "homeName": nom(h), "awayName": nom(a), "score": m.get("score"), "halftime": m.get("halftime"),
                       "stats": m.get("stats"), "odds": m.get("odds"), "prediction": p, "h2h": h2h(d.D, h, a)})
    vus = {}
    for m in matchs:                                      # URL courte (/match/manchester-city-vs-arsenal), datée seulement si doublon
        vus[m["slug"]] = vus.get(m["slug"], 0) + 1
    for m in matchs:
        if vus[m["slug"]] > 1:
            m["slug"] = f"{m['slug']}-{m['kickoff'][:10]}"
    perf = performances(pred, journal)
    perf["confidence"] = conf["levels"]
    perf["families"] = CF.resume_familles(A_bt)
    perf["byDay"] = CF.suivi_jours(M_bt)
    perf["backtest"] = {"matches": int(len(M_bt)), "markets": int(len(A_bt)), "seasons": [int(s_cur - 5), int(s_cur)],
                        "lastDate": M_bt.date.max().date().isoformat() if len(M_bt) else None}
    jours_ = journees(matchs, bruts, conf)
    maintenant = datetime.combine(rejeu, datetime.min.time()).replace(hour=12, tzinfo=timezone.utc) if rejeu else datetime.now(timezone.utc)
    meta = {"generatedAt": datetime.now(timezone.utc).isoformat(), "dataAsOf": date_dataset.isoformat(), "resultsAddedFromApi": info["resultsAdded"],
            "mode": mode, "referenceDate": jour0.isoformat(), "now": maintenant.isoformat() if rejeu else None, "model": VERSION,
            "sources": info["sources"], "liveScores": mode == "live"}
    recents = d.D[d.D.Season >= int(d.D.Season.max()) - 12]
    index = {ts(e): {"name": nom(e), "short": e, "code": code(e), "color": couleur(e)} for e in sorted(set(recents.HomeTeam) | set(recents.AwayTeam))}
    fichiers = {"meta.json": meta, "team-index.json": index, "competitions.json": competitions, "teams.json": list(profils.values()), "standings.json": standings,
                "matches.json": matchs, "performance.json": perf, "markets.json": {"rows": marches_a_venir(matchs, perf.get("tiers")), "tiers": perf.get("tiers")},
                "days.json": jours_}
    if mode in ("live", "fixtures"):
        fichiers["journal.json"] = journal
    for f, obj in fichiers.items():
        with open(os.path.join(sortie, f), "w", encoding="utf-8") as fh:
            json.dump(obj, fh, ensure_ascii=False, separators=(",", ":"), default=lambda o: o.item() if hasattr(o, "item") else str(o))
    print(f"{len(matchs)} matchs · {len(profils)} équipes · mode {mode} · données au {date_dataset} (+{info['resultsAdded']} résultats récents) → {sortie}")
    return meta


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--sortie", default="web/data"); ap.add_argument("--source", default=None, help="chemin ou URL de Matches.csv")
    ap.add_argument("--date", default=None, help="date de référence AAAA-MM-JJ (par défaut aujourd'hui)")
    ap.add_argument("--rejeu", default=None, help="rejoue une date passée AAAA-MM-JJ avec uniquement les données antérieures")
    a = ap.parse_args()
    exporter(a.sortie, a.source, date.fromisoformat(a.date) if a.date else None, date.fromisoformat(a.rejeu) if a.rejeu else None)
